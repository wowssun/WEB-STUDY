# page 47 ---------------------------------------

# 1.

height <- c(180,165,170)
mean(height)   # 171.6667

# 2.

your_info <- c('우선제',27,'여자')
paste('나의 이름은',your_info[1],'이고 나이는 ', your_info[2],'세 성별은 ', your_info[3],'입니다.')

# 3.

height_list <- list(철수=180, 영희=165, 지수=170)
height_list <- unlist(height_list,use.names = FALSE)
sum(height_list)   # 515
mean(height_list)  # 171.6667

# 6.

x3 <- c(1,2) # 객체 생성 가능

# page 78 ~ 79 ---------------------------------------

# 1.
icecream <- c("Babamba", "Bibibic","wa","melona","Bapiko","tankboy","hodumaru")
rev(sort(icecream))

# 2 

do1 <- 3+4-5*6/3*0.7-4+27/3+3-2*6
do2 <- 3+(4-(5*6/(3*0.7-4)+27))/3+(3-2*6)
do1 - do2

# 3.

90000 / 20 # 한사람당 4500원씩 사용가능. 모두 동일메뉴를 구매해야 하니, 구매가능한 대만밀크티가 제일 비싼 메뉴이다.

4700 *10 + 4200 * 10 # 각 메뉴의 최대값으로 계산했을때 90000원이 넘지않아서 대만밀크티 아이스가 구매가능한한 제일 비싼 메뉴이다.

# 4. 

produce <- c('강미나','김도연','김세정','김소혜','김청하','유연정','임나영','전소미','정채연','주결경',
             '최유정','강시라','기희현','김나영','김소희','박소연','윤채경','이수현','이해인','전소연','정은우')
sort(produce)
rev(sort(produce))

# 5.

# x=나이, y=소득, z=근무일수 ,m=혼인여부, p=본인세대 자산가액, c=청약가입여부, a=자동차가액

gabdol <- c(x = 36 , y = 3000, z = 365*2, m ='미혼', p = 2350 , c = '가입' , a = 2000 )

if(x >= 19 && x <= 39){
  if(m == '미혼'){
    if((y/12) <= 300){
      if(p <= 23700 && a <= 2468 ){
        paste('청년 주택청약 가능')
      }else{
        paste('재산조건 미충족')
      }
    }else{
      paste('소득조건 미충족')
    }
  } else {
    paste('혼인여부 미충족')
  }
}else{
  paste('사회초년생 주택청약을 알아보세요.')  
}

# page 99 ~ 100 ---------------------------------------

# 1

hang <- matrix(seq(1:15), nrow =3, ncol=5, byrow = T) # byrow를 써주면 행부터 순서대로 채워진다.
hang

# 2

yeol <- matrix(seq(1:15), nrow=3, ncol=5)
yeol

# 3

sam_sam <- matrix(seq(1:9), nrow = 3, ncol = 3, byrow = T)
sam_sam

# 4

A <- array(1:27, dim = c(3, 3, 3))

A[1, 2, 3]      # 22

A[1, 2,  ]      # 4 13 22

A[1,  ,  ]      #      [,1] [,2] [,3]
                # [1,]    1   10   19
                # [2,]    4   13   22
                # [3,]    7   16   25

A[1,  , 3]      # 19 22 25  

dim(A)          # 3 3 3   dim=c(행의 수, 열의 수, 차원 수)

# 5

eng <- c(70, 80, 95)
name <- c('sunhee','meehee','youngmee')

Aclass <- cbind(name,eng)
Aclass

# 6

# (a)
library(readxl)

baseball <- read_excel('baseball.xlsx')
baseball

write.csv(baseball,'baseball.csv')

# (b)

# 오름차순
baseball_1 <- baseball [order(baseball$홈런),]
baseball_1 <- cbind(baseball_1$선수명,baseball_1$홈런)

# (c)

# 내림차순
baseball_2 <- baseball [order(baseball$홈런,decreasing = TRUE),]
baseball_2 <- cbind(baseball_2$선수명,baseball_2$홈런)

# (d) 이거 비율이상함 
bss <- round(0.4 *baseball$볼넷 -  0.3*baseball$삼진,2) 
bss

baseball <- cbind(baseball,bss)
baseball

# (e)


# (f)

# (g)


#(h)

#(i)

# page 131 ~ 132 (사이트 자료 다운로드)

# 1 
hang1 <- cbind(seq(2, 8, by=2) , seq(3, 12, by = 3), c(5, 8, 15, 20))


# 2
hang1 <- cbind(hang1, seq(7, 28, by=7) )

# 3
hang1 <- rbind(hang1, c(10, 15, 25, 35) )

# 열이름 변경하기 ( colnames )
colnames(hang1)<-c('a', 'b', 'c', 'd')


# 행이름 변경하기 ( rownames )
rownames(hang1)<-c('가', '나', '다', '라','마')

hang1

# 4
#(a)
csv_exam <- cbind(c('똘이','떵이','호치','새초미','드라고','요룡이','마초','미미','몽치','키키','강다리','찡찡이'),
                  c(1,1,1,1,1,2,2,2,2,2,2,2),
                  c(90, 50, 96, 50, 95, 80, 10, 80, 100, 70 ,75, 40),
                  c(90, 60, 93, 30, 90, 90, 10, 83, 80, 86, 52, 36),
                  c(90, 30, 98, 70, 95, 85, 60, 87, 45, 68, 53, 58))


# 파일 만들기
write.csv(csv_exam, 'csv_exam_1.csv ', quote = F, row.names = F)
          
csv_exam <- read.csv('csv_exam_1.csv ', header = T)

colnames(csv_exam) <- c('이름','반','국어','수학','영어')

csv_exam

#(b)

ggplot(data = csv_exam, aes(x=csv_exam$국어, y=csv_exam$수학)) +    # 어떤 데이터를쓰고 ,x축과  y축을 어떤 데이터를 사용할건지지
  geom_point()  # 산점도로 표현

#(c)

ggplot(data = csv_exam, aes(x=csv_exam$반, y=csv_exam$국어)) +    # 어떤 데이터를쓰고 ,x축과  y축을 어떤 데이터를 사용할건지지
  geom_point() +  # 산점도로 표현
  xlim(1, 2 )   

# page 355------------------------------------
# 영어 지문에서 단어추출 빈도수수

library(httr)
library(rvest)
library(XML)
library(NLP)
library(tm)
library(stringr)
library(wordcloud2)

obama_url = 'https://www.chosun.com/site/data/html_dir/2009/01/21/2009012100180.html'

web_page <-read_html(obama_url)  # 웹페이지 읽어보기
web_page

html <- htmlParse(web_page,encoding = 'utf-8')  # html만가져오기기

p <- xpathSApply(html,"//p[@class=' article-body__content article-body__content-text | text--black text font--size-sm-18 font--size-md-18 font--primary']",xmlValue)  # p태그 가져오기
p

p <- tolower(p)    # 모두 소문자로 변경

p <-gsub('\n','', p)   # \n 제거
p <-gsub('\r', '' ,p) # \r 제거
p <-gsub('\t', '' ,p)  # \t 제거

p_txt <- Corpus(VectorSource(p)) # 말뭉치화
p_txt <- tm_map(p_txt,removeNumbers)   # 숫자 제거 
p_txt <- tm_map(p_txt,removePunctuation)   # 구두점 제거
p_txt <- tm_map(p_txt,stripWhitespace)   # 공백 제거
p_txt <- tm_map(p_txt,removeWords,stopwords('en'))   # 불용어 제거, 관사, 전치사 등

# p_txt <- tm_map(p_txt,stemDocument) # 단어의 줄기 추출

p_mtx <- TermDocumentMatrix(p_txt) # 말뭉치 행렬화
p_mtx <- as.matrix(p_mtx)         # 행렬로 반환
p_mtx <- sort(rowSums(p_mtx), decreasing = T)   # 빈도수 내림차순 정렬
p_mtx <- data.frame(word=names(p_mtx), freq=p_mtx, stringsAsFactors = F) # 데이터프레임으로 변환

wordcloud2(p_mtx)
