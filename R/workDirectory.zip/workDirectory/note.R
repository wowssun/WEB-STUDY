print('Hello World')
print('hi')

x<-1     # 변수에 저장
y<-2
z <- x + y
z

# 주석
# 입력 후 ctrl + enter 실행
# 블럭 설정 후 ctrl + enter는 여러 줄 실행
# 콘솔 지우기는 crtl + l
# 주석 설정 및 해제는 ctrn,l + shift + c


# column vector
# - 같은데이터 타입을 갖는 요소들의 집합
# - 벡터에 대한 연산은 자동으로 각 구성요소에 대한 연산이 됨
# - c() 함수 : 열벡터 생성


numz <- c(1, 3, 5, 7, 9)  # 한줄 벡터 
numz
numz[4]  # 인덱스는 1부터 시작, 4번째 인덱스 요소
numz[2:4]  # 2번째 ~ 4번째 인덱스 요소
length(numz) # 5  벡터의 길이 조회 함수

one2oh <- c(1:5)   # 변수에 범위를 줘서 저장 가능
one2oh

two2ten <- seq(2, 10)  # 연속되는 숫자(시퀀스)
two2ten

two2ten <- seq(2, 10, by=2)   # 2씩 증가되는 벡터
two2ten

one2sam3 <- rep(1: 3, times=3)   # 1부터 3까지 3번반복
one2sam3

#############################
charz <- c('hello', "hi", 'bye')  # 이중이나 단일따옴표 사용해도도
charz   #  "hello" "hi"    "bye"   모두 결과적으로 이중따옴표로 출력

#############################
boolz <-c(TRUE, FALSE, T, F)
boolz   #  TRUE FALSE  TRUE FALSE


varz <- c(1, 2.0, '삼', "사", NULL, NaN, NA, T)
# NaN : Not A Number
# NA : Not Available

varz  #  "1"    "2"    "삼"   "사"   "NaN"  NA     "TRUE"
# 다양한 데이터타입을 담을 수 있다. 대신 문자열처럼 취급한다.
length(varz)  # 7 NULL이 안들어가서

typeof(boolz)   # "logical"
typeof(varz)    # "character"
typeof(charz)   # "character"
typeof(numz)    # "double"
###########################
numz          # 1 3 5 7 9
numz * 3      # 3  9 15 21 27    각 요소에 3이 곱해진다.

one2oh    # 1 2 3 4 5
two2ten   #  2  4  6  8 10
one2oh + two2ten   # 3  6  9 12 15 각 요소끼리 더해진다.

mean(numz)      # 평균
max(numz)       # 최대값
min(numz)       #최소값
sum(numz)       # 합계
median(numz)    # 중앙값

sum(numz[1:3])  # numz 벡터의 1 ~ 3번째 요소의 합계

mean(numz[1:3])  # numz 벡터의 1 ~ 3번째 요소의 평균

charz
paste(charz) 
paste(charz, collapse=',')   # , 구분해서 넣어줌 "hello,hi,bye"
paste(charz, collapse=' ')   # 문자열 연결처럼 하나로 합쳐진 상태 "hello hi bye"

length(charz)   # 3
length(paste(charz, collapse=','))   # 1
length(paste(charz, collapse=' '))   # 1 
 

#############################################

# factor 요인 벡터
# - 범주형 데이터를 저장하기 위해 사용
# - 저장되는 값이 대상을 분류하는 의미를 가짐
# - 산술 연산 불가능
# - 범주가 취할 수 있는 값의 수준 : level
# - levels( ) 함수로 확인
# - 열 벡터 생성 후,
#   as.factor() 함수를 이용하여 변환하거나
#   factor( ) 함수를 이용


vec <- c(1, 2, 3, 1, 2)     # 열 벡터
fac <-as.factor(vec)        # 요인 벡터
fac <- factor(c(1, 2, 3, 1, 2))   # 요인 벡터

vec    # 1 2 3 1 2
fac   # 1 2 3 1 2    Levels: 1 2 3   범주로 나옴
 
class(vec)    # "numeric"
class(fac)    # "factor"

typeof(vec)   # "double"
typeof(fac)   # "integer"

vec       # 1 2 3 1 2
vec + 1   #  2 3 4 2 3

fac         #  # 1 2 3 1 2    Levels: 1 2 3 
fac + 1      # NA NA NA NA NA   에러

levels(vec)  # NULL
levels(fac)  # "1" "2" "3"


#########################
# R의 데이터 타입은 변수 생성 시 자동으로 결정
# - 생성된 변수의 유형은 typeof( )함수로 확인

# 변수 생성
# 변수 이름 <- 값

# 변수명 생성규칙
# - 첫글자는 영문자 또는 마침표
# - 두번째 글자 이후로 영문자, 숫자, 밑줄 사용 가능
# - 대문자, 소문자 구분
# - 빈칸 및 예약어 사용 불가

# R의 데이터 타입
# - character
# - double : 기본형
# - integer : as 또는 L을 이용
# - boolean
# - Date

# - NULL, NA, NaN
# - Inf ( 양의 무한대 ), -Inf ( 음의 무한대 )
# - closure( 함수형 ) - 함수 저장

f = function(num1, num2){   # 변수에 함수 저장
  return (num1 + num2)
}

typeof(f)   # "closure"

f(1, 2)   # 함수 호출 


one <- '하나'
two <- '2'
sam <- 3
saa <- 4.0
ohh <- 5L
six <- as.integer(6)

cham <- TRUE
no_cham <- F
typeof(cham)      # "logical"
typeof(no_cham)   # "logical"

date <- '2023-11-22'
date    # "2023-11-22"

typeof(date)   # "character"
class(date)    # "character"

datee <- as.Date(date)

typeof(datee)   # "double"
class(datee)    # "Date"

today <- Sys.Date()   # 현재 시점의  날짜와 시간
today   # "2023-09-19" 
paste('오늘은', today)   # "오늘은 2023-09-19"


typeof(one)   # "character"
typeof(two)   # "character"
typeof(sam)   #  "double"
typeof(saa)   #  "double"
typeof(ohh)   # "integer"
typeof(six)   # "integer"

class(one)   # "character"
class(two)   # "character"
class(sam)   # "numeric"
class(saa)   #  "numeric"
class(ohh)   # "integer"
class(six)   # "integer"

ls()           # 변수 목록 확인 
rm(no_cham)    # 변수 삭제

##################################
# list : 여러 데이터 타입 저장 가능
list0 <- list(1, 2.0, '3', "사", NaN, T)

list0   # [[1]]   리스트  1번째째
        # [1] 1   데이터가 한개, 값값 

list1 <- list(c(1, 2), c('a', 'b'))

list1     # [[1]]      [[2]]
          # [1] 1 2    [1] "a" "b"

list1[1]  # [[1]] 
          # [1] 1 2 

list1[[1]]   # [1] 1 2


list1[2]   # [[1]] 
           # [1] "a" "b"  

list1[[2]]  #  "a" "b"

list2 <- list(x=c(10, 20), y=c(T, F))  # 리스트만들때 변수에 값을 저장도 가능

list2    # $x          $y
         # 10 20       TRUE FALSE

list2[1] # 위와 같이 나온다.
list2$x   # 10 20
list2$y   # TRUE FALSE

###########################################

score_list <- list( Kim=70, Lee=80 )   # $Kim [1] 70  $Lee [1] 80
score_list <- c(score_list, list(Han=90))   # 데이터 추가

# $Kim [1] 70  $Lee [1] 80  $Han [1] 90

unlist(score_list)  # 리스트를 벡터로 변환
# Kim Lee Han 
#  70  80  90 

scores <- unlist(score_list, use.names = FALSE)   # 이름은 제외하고 점수만 추출

scores     # [1] 70 80 90

total_score <- sum(scores)  # 240

avg_score <- mean(scores)   # 80

typeof(score_list)    # "list"
typeof(scores)        # "double"
typeof(total_score)   # "double"
typeof(avg_score)     # "double"


#####################################

demo(graphics)

demo(persp)

x <-c(2, 3, 4, 5, 7, 8)
y <-c(1, 3, 2, 6, 7, 2)
plot(x, y, type = 'l')   # type에 l을 넣어서 라인그래프


####################################
# 패키지 설치하기
library(ggplot2)  #import 처럼 이렇게 써보고 없으면 에러가 뜨니 설치를 해야한다.

install.packages('ggplot2') # install을 사용하여 설치
library(ggplot2)


b_type <- c('A', 'B', 'O', 'AB', 'A')
b_type
qplot(b_type)   # 빈도 그래프

qplot(data=mpg, x=hwy)

###################################
1 + 2   # 3
2 - 3   # -1
3 * 4   # 12

4 / 5   # 나눗셈셈 0.8
4 %/% 5   # 몫 0
4 %% 5     # 나머지 구하기 4

2 ^ 3     # 제곱 8
2 ** 3    # 제곱  8

##########################

a <- 1:5   # 1 2 3 4 5
a
a > 3   # FALSE FALSE FALSE  TRUE  TRUE
a < 6   # TRUE TRUE TRUE TRUE TRUE

a > 3 & a < 6   # FALSE FALSE FALSE  TRUE  TRUE  두개 모두 TRUE 여야 TRUE

a > 3 | a < 6  # TRUE TRUE TRUE TRUE TRUE  둘 중 하나만 TRUE여도 TRUE

sum(a > 3 | a < 6)   # 5  TRUE 개수
sum(a > 3 & a < 6)   # 2

b <- 2
c <- 3

b > 1 && c < 1   # FALSE
b > 1 || c < 1   # TRUE

a > 3 || a < 6  # Error in a > 3 || a < 6 : 'length = 5' in coercion to 'logical(1)'

cat('b : ' , b) #  b :  2 cat은 출력할때 줄바꿈하지 않는다.
paste('b : ' , b) # "b :  2"
cat('b : ' , b,'\n')  # 이렇게 줄바꿈 넣어주기 문자열 결합만 함.

one2five <- c(1:5)  # 1 2 3 4 5
five2one <- 5:1     # 5 4 3 2 1
one2five   
five2one

one2five > five2one   # FALSE FALSE FALSE  TRUE  TRUE
which(one2five > five2one)     # 4 5 무엇이 TRUE인지 조회할 수 있다.

abc <- c('a', 'b', 'c')
xbc <- c('x', 'b', 'c')
abc == xbc   # FALSE  TRUE  TRUE

which(abc== xbc)  # 2 3 무엇이 TRUE인지 인덱스로 알려준다.
intersect(abc, xbc)    # "b" "c"   무엇이 TRUE인지 요소의 정보를 알려준다.

xbcc <- c(xbc, 'c')
xbcc   # "x" "b" "c" "c"

sort(xbcc)        # "b" "c" "c" "x"  오름차순 정렬(기본)
rev(sort(xbcc))   # "x" "c" "c" "b" 내림차순 정렬 / 정렬한 것을 reverse 함수에 넣어서 

unique(rev(sort(xbcc)))   # "x" "c" "b" 중복 제거

replace( xbcc, xbcc == 'b', 'y')  #  "x" "y" "c" "c"   xbcc에 b가 있으면 y로 바꾸기

replace( xbcc, list=c(3,4), values=c('z','!'))  #  "x" "b" "z" "!" 리스트의 3, 4번째 인덱스를 지정해서 


################################################
id <- c(1, 2, 3)
mid_term <- c(70, 80, 90)
final_term<- c(77, 87, 97)

# 중간고사에서 40%, 기말고사 60%의 비중으로 total 계산
total <- (mid_term * 0.4) + (final_term * 0.6)

# 벡터를 결합하여 행렬 만들기
scorez <- cbind(id, mid_term, final_term, total)

scorez


# 행렬 정렬
scorez [ order(scorez[,4]),]   #행렬의 4번째열을 기준으로 오름차순 정렬  , 빼먹지 않기

# 행렬 정렬
scorez <- scorez [ order(scorez[,4], decreasing = TRUE),]     # 행렬의 내림차순 정렬

scorez

max(mid_term)  #  현재 벡터에서의 최대값 90
max(mid_term, final_term)  # 두 백터에서의 최대값 ,97 mid_term, final_term 모두에서 최대값 찾음.

pmax(mid_term, final_term)  #두 벡터의 각 위치에서의 최대값,  77 87 97 같은 행에서 비교해서 최대값 찾음.

# 최소값도 동일하다


#########################################
# total 평균계산해서 avg에 저장
avg <- mean(total)
paste('class average is ',avg)

# avg가 90 이상이면 grade는 A
# 80 이상이면 B
# 그 외의 경우에는 c

if (avg >= 90) {
  grade <- 'A'
}else if(avg >= 80){
  grade <- 'B'
}else{
  grade <- 'c'
}

paste('class grade is ' , grade)

# grade가 a이면 Aclass
# 그렇지 않으면 Not Aclass

if(grade=='A'){
  paste('Aclass')
}else{
  paste('Not Aclass')
}

# 삼항연산자로 써보기
ifelse(grade=='A' , 'Aclass', 'Not Aclass')  # 값만 써도 된다.



##########################################
# switch(값 또는 변수 ,
#         조건문1,
#         조건문2,
#           ... 
#         #default는 조건없이 )

switch(grade, 
       'A'= level <- 'high',   # 여기에 'A'= {level <- 'high'} 처리할게 많으면  이렇게 대괄호해도 된다
       'B'= level <- 'under high',
       'C'= level <- 'bottom high',
            level <- 'not high')   # 마지막은 조건없이
       
paste('level is ', level)

#########################################3

sum <- 0   # 0으로 초기화
for (i in 1:10) {    # 범위나 벡터쓰기
  sum <- sum + i 
  cat(sum, ' ')       # 1  3  6  10  15  21  28  36  45  55
  if(i == 5) break    # i가 5가 되면 break
 
}


##########################################
# matrix
# - 벡터를 행/ 열로 구성
# - 
#행렬이름 <- matrix(행렬에 넣을 값 또는 변수, ncrow=행의 수, ncol=열의 수)
#
# - 행렬에 값 저장
# 행렬이름[행,렬] <- 값

# nrow 행 ncol 열, 열먼저 채운다.
sam_saa <- matrix(seq(1:12), nrow=3, ncol=4)

# 3행 3열의 값 변경하기
sam_saa[3,3] <- 99
sam_saa

# ( 행추가) 4행에 2부터 8까지 2씩 증가. 값 추가

sam_saa <- rbind(sam_saa,seq(2, 8, by=2))   # seq 자리에 값이 담겨있는 변수써도 됨.
sam_saa

# ( 열추가 ) 4열에 1부터 7까지 2씩 증가. 값 추가하기

sam_saa <- cbind(sam_saa,seq(1, 7, by=2))
sam_saa

# 열이름 변경하기 ( colnames )
colnames(sam_saa)<-c('1st', '2nd', '3rd', '4th', '5th')
sam_saa

# 행이름 변경하기 ( rownames )
rownames(sam_saa)<-c('1행', '2행', '3행', '4행')
sam_saa

##################################################
# array
# - 다차원 벡터
# - matrix는 2차원, array 차원 제한 x
# - array() 함수를 이용해서 생성
# - array( 값 또는 변수, dim=c(행의 수, 열의 수, 차원 수))

arr232 <- array(1:12, dim = c(2, 3, 2))  # 2행 3열 2차원 배열

arr232[1,  ,  ]

arr232[1, 1, 1]

arr232[1, 1, 2]  # 1행 1열 2차원

arr232[ , 2,  ]  # 2열만 나오도록

arr232[1, 2,  ] # 1행의 두번째열들


##############################################
# data frame
# - 2차원 데이터셋 표현
# - 엑셀 데이터를 읽었을 때 data.frame이 됨
# - 열 : 변수
# - 행 : 관측 객체
# - 각 행렬이 서로 다른 데이터 형식을 가질 수 있음
# - data.frame( ) 함수 이용

kor <- c(99, 88, 77, 66)
eng <- c(90, 80, 60, 70)
math <- c(50, 60, 100, 20)

df_mid_term <- data.frame(eng, math, kor)
df_mid_term

# 행렬 이름 변경하기
colnames(df_mid_term)<-c('java', 'db', 'jsp')
rownames(df_mid_term)<-c('Kim', 'Lee', 'Han', 'Sin')

df_mid_term

nrow(df_mid_term)  # 행의 개수
ncol(df_mid_term)  # 열의 개수
dim(df_mid_term)   # 행과 열의 개수

head(df_mid_term, 2) # 앞쪽에 있는 데이터 대략 , 앞에서부터 2행 ( 빅데이터에서는 범위를 지정안하면 대략 몇개 나옴)

tail(df_mid_term, 2) # 뒤쪽에 있는 데이터 대략 몇개, 뒤에서부터 2행

df_mid_term[1, 2]   # 1행 2열

df_mid_term[1, ]    # 1행만

df_mid_term[ , 2]   # db열의 데이터만  50  60 100  20

df_mid_term[ , c('java','db')]    # 열의 이름을 지정해놓았으니 열의 이름으로 데이터를 가져올 수 있다. 여러개 가져와서 벡터형태로 가져온것. 열 형태로 가져옴.

df_mid_term[ , 'db']  # 50  60 100  20

df_mid_term[ , 'db',drop=FALSE]  # 이렇게 하면 원래 열의 형태로 가져온다.

df_mid_term$db  # 50  60 100  20

# 자바 열에 들어있는 점수들의 평균과 최대값 구하기
mean(df_mid_term$java)
max(df_mid_term$java)

################################3
# RData 파일
# - R 전용 데이터 파일
# - 용량 작고 빠름
# - 저장 : sava()
# - 읽어오기 : load( )

# 데이터 프레임을 rda 파일로 저장
save(df_mid_term, file='df_mid_term.rda')
rm(df_mid_term)    # 삭제
df_mid_term        # Error: object 'df_mid_term' not found

# 파일 읽어오기

load('dif_mid_term.rda')
df_mid_term
View(df_mid_term)

################################
list3 <- list(df_mid_term, c(10 ,20 ,30) , c('a', 'b')) # 3개의 공간에 넣기?
# c() 열벡터로 묶어서 넣기

# list 각 해당 부분 이름 변경하기
names(list3)<-c('df', 'num_vec', 'char_vec')

# 10 20 30 출력하기 
list3$num_vec
list3[[2]]  # 값만 나오도록 하려면 이렇게 해야함.
list3[2]  # 이렇게 해도 나오지만 

list3$num_vec[3]   # 30
list3[[2]][3] # 여기 괄호 몇개 써야하는거징? list3[[2]][[3]] 이렇게 해도 값이 나옴.

#####################################
df_csv <- read.csv('csv_exam.csv')    # csv 파일 읽어오기
df_csv
head(df_csv)
tail(df_csv)
df_csv2 <- read.csv('csv_exam_headerX.csv') # 헤더가 없는 파일은 첫번째 행을 헤더처럼 읽는다.
df_csv2 <- read.csv('csv_exam_headerX.csv',header = FALSE)  # 그래서 이렇게 조건 추가해야함.
df_csv2   


mean_math <- mean(df_csv$math)
mean_eng <- mean(df_csv$english)
mean_science <- mean(df_csv$science)

max_math <- max(df_csv$math)
max_eng <- max(df_csv$english)
max_science <- max(df_csv$science)

# csv_stat 행렬에 평균, 최고점수 담기

# cbind로 이렇게 추가해도 된다.
csv_stat <- cbind(c(mean_math,mean_eng,mean_science))
csv_stat <- cbind(csv_stat,c(max_math, max_eng, max_science))

# 한번에
csv_stat <- cbind(c(mean_math,mean_eng,mean_science), c(max_math, max_eng, max_science))

csv_stat

# 파일 만들기
write.csv(csv_stat, 'csv_exan_stat1.csv')

# 헤더 이름 변경해주기 (지정하기)

colnames(csv_stat) <- c('average','max')
rownames(csv_stat) <- c('math','english','science')

write.csv(csv_stat, 'csv_exam_stat2.csv')



#################################
# df_mid_term 데이터프레임을
# df_mid_term.csv 파일로 저장

write.csv(df_mid_term,'df_mid_term.csv')

#################################
# txt 파일읽어오기

txt <- read.table('txt_exam.txt',header = TRUE) # 지금은 헤더가 있어서 헤더가 있다고 표시해준다

txt <- rbind(txt, c(4, 70, 170))

# txt 파일로 저장하기, 따옴표 없애기, 열들끼리 구분자 탭공백 주기, 행이름 빼기
write.table(txt,'txt_exam_write.txt' ,quote=FALSE, sep = '\t', row.names = FALSE)
# 원본파일로 확인하면 다 변경되어 있음. 


######################################
# excel 파일 읽기
install.packages('readxl')
library(readxl)

df_xls <- read_excel('excel_exam.xlsx')
df_xls

df_xls2 <- read_excel('excel_exam_headerX.xlsx',col_names = FALSE)
df_xls2

####################################################
# excel 파일 쓰기

install.packages('xlsx')
library(xlsx)   

# error : JAVA_HOME cannot be determined from the Registry
# JAVA_HOME에서 경로 잡아줄때  bin을 빼고 잡아준다.

# excel 파일에서 특정 sheet 읽기기
df_xls3 <- read_excel('excel_exam_sheet.xlsx',sheet = 3)   # 3번째 sheet 읽어오기
df_xls3

art<-seq(10, 80, by=10)
df_xls3 <- cbind(df_xls3,art)
df_xls3

write.xlsx(df_xls3, 'excel_exam_write.xlsx',row.names = FALSE)

df_xls4  <- read_excel('excel_exam_write.xlsx')

df_xls4

###########################################
library(ggplot2)

data(diamonds, package = 'ggplot2')
head(diamonds)
dim(diamonds)
str(diamonds)

############################################
# csv 파일 읽어오기
traffic_csv <- read.csv('traffic_2022.csv',fileEncoding = 'euc-kr')    

traffic_csv

# 사고건수 / 사망자수 => 사망률 새로운 열 추가

death_rate <- (traffic_csv[4]/traffic_csv[3] * 100)

colnames(death_rate)<- '사망률'


death_rate <-cbind(traffic_csv[1],traffic_csv[2],round(death_rate,2))

write.csv(death_rate,'death_rate.csv', quote=F, row.names=F)

colnames(death_rate)<- c('법규위반','주야','사망률(%)')

#########################################
x <-1
y <-2
plot(x,y)

x<- seq(0, 1, length = 10)
y <- x
plot(x, y, type='l')

colors()

############################################################3
library(ggplot2)

# 산점도Scatter plot
# -데이터를 x축과 y축에 점으로 표현한 그래프
# - 연속된 값으로 된 두 변수의관계 표현
# - geom_point( )

ggplot(data = mpg, aes(x=displ, y=hwy)) +    # 어떤 데이터를쓰고 ,x축과  y축을 어떤 데이터를 사용할건지지
          geom_point() + # 산점도로 표현
          xlim(3, 6 ) +  # x축을 3부터 6까지만 , x축 값의 범위
          ylim(10, 30)   # y축 값의 범위



# 위에서 했던 death_rate 파일로 그래프 만들어보기


traffic_csv <- read.csv('traffic_2022.csv',fileEncoding = 'euc-kr') 
traffic_csv

ggplot(data = traffic_csv, aes(x = 가해자법규위반, y = 사망자수)) +    # 어떤 데이터를쓰고 ,x축과  y축을 어떤 데이터를 사용할건지지
  geom_point(aes(size=사고건수, color=중상자수)) + # 산점도로 표현  사이즈와 색 표시
  theme(axis.text.x = element_text(angle = 45, hjust=1))

###################################################
# 막대그래프 bar chart

# 평균 막대 그래프
# - 각 집단의 평균값을 막대 길이로 표현
# - 데이터를 요약한 평균표를 먼저 만든 후
#   평균표를 이용하여 그래프 생성
# - geom_col( )

str(mpg)

# mpg 데이터셋의 drv별로 평균hwy를 df_mpg에 저장

library(dplyr)

df_mpg <- mpg %>% group_by(drv) %>% summarise(avg_hwy = mean(hwy))

df_mpg
#(1) 평균 막대 그래프로 표시
ggplot(data=df_mpg, aes(x=drv, y=avg_hwy )) +  geom_col()

# 정렬해서 쓰거나
df_mpg [order(df_mpg$avg_hwy, decreasing= T),]

#(2) 크기 순서로 그래프 표시
ggplot(data=df_mpg, aes(x=reorder(drv, -avg_hwy), y=avg_hwy )) +  geom_col()

#----------------------------------------------

# suv 차종class 평균 도시연비 cty가
# 가장 높은 제조사 manufacturer 다섯 곳을
# 막대 그래프(연비가 높은 순서)로 표시



suv_mpg <- mpg %>% filter(class=='suv') %>% group_by(manufacturer) %>% summarise(avg_cty = mean(cty)) %>% arrange( desc(avg_cty)) %>%head(5)

ggplot(data=suv_mpg, aes(x=reorder(manufacturer, -avg_cty), y=avg_cty )) +  geom_col()


# ------------------------------------------------

# 빈도 막대 그래프
# - 값의 개수(빈도)로 막대 길이를 표현
# - 별도로 표를 생성하지 않고 그래프 생성
# - geom_bar( )

library(ggplot2)

ggplot(data = mpg, aes(x=drv)) + geom_bar()

ggplot(data = mpg, aes(x=class)) + geom_bar()



###############################################
# 선 그래프
# - 데이터를 선으로 표현현
# - geom_line( )

ggplot(data = economics, aes(x=date, y=unemploy)) + geom_line()

ggplot(data = economics, aes(x=date, y=psavert)) + geom_line()

#################################################
# 상자 그림 box plot
# - 데이터의 분포 형태를 직사각형 상자 모양으로 표현
# - geom_boxplot( )

ggplot(data = mpg, aes(x=drv, y=hwy)) + geom_boxplot()

# diamonds 데이터 확인하기
data("diamonds", package = 'ggplot2')
head(diamonds)

# 히스토그램
# main 그래프 이름
# xlab x축이름, ylab y축이름
hist(diamonds$carat, main = 'Carat histogram', xlab = 'carat',col = 'blue')


############################################

foreigner <- read.csv('foreigner_2021.csv')    # csv 파일 읽어오기
head(foreigner)
str(foreigner)

# 1월 입국자의 성별 합계
foreigner_jan <- tapply(foreigner$X01, foreigner$성별, sum)
foreigner_jan

# 색 여러개  c() 열벡터로 
barplot(foreigner_jan, col=c('lightblue','pink'))

#  데이터 숫자 가로로 표시
barplot(foreigner_jan, col=c('lightblue','pink'), las=1)

# 월별 입국자 수의 합계 막대 그래프

# 행방향 말고 열방향에서 4:15까지만 평균을 구하니까 행범위는 비워두고 열범위만 체크해서 넣는다. 
foreigner_mon <- colMeans(foreigner[,4:15])

barplot(foreigner_mon, col=c('lightyellow','lightpink'))


# 중국, 필리핀, 한국계중국인, 미안마 국적 입국자의
# 1월 성별 유입 인구수를 막대 그래프로 표시
asia4 <-foreigner[1:8, ,]
asia4

# 그냥 수치를 입력하면 에러가 뜬다. 그때는 geom_bar(stat = 'identity') 추가한다.
# stat는 count가 기본값임.
# stat = 'identity'의 의미는 x축의 빈도수가 아닌 y축의 숫자를 기반으로 막대그래프를 그린다는 뜻.

ggplot(data = asia4, aes(x=asia4$국적,y=asia4$X01,fill=asia4$성별)) + geom_bar(stat = 'identity')


############################################################
#apply( ) : 행 별 또는 열 별 반복 계산 시 사용

one2nine <- matrix(1:9,nrow=3)
apply(one2nine, 1, sum)    # 각 행의 합계
apply(one2nine, 2, mean)   # 각 열의 합계

one2nine[2,2] <- NA
one2nine

#NA를 제외하고 계산하도록 처리
apply(one2nine, 1, sum, na.rm=T)    # 각 행의 합계 NA가 있을시 제외하기.
apply(one2nine, 2, mean)   # 각 열의 합계

# abcd에 각 데이터 저장
a <- matrix(seq(1:9), nrow=3, ncol=3)
b <- c(1, 2, 3, 4, 5)   # 1:5
c <- matrix(c(1,2,3,-3,-2, -1), nrow = 2, ncol = 3, byrow = T)   #rbind(c(1:3 , -3:-1)
d <-2

# a= 이렇게하면 각 리스트에 이름 저장가능
listz = list(a=a,b=b,c=c,d=d)
listz
lapply(listz, sum)   # 리스트일경우

##############################################

data("diamonds")
head(diamonds)

# 그룹별 작업 처리
# aggregate( )

# 각 cut의 평균 price
aggregate(price~cut, data=diamonds, mean)

# 각 cut의 평균 price, carat
aggregate ( cbind(price,carat)  ~ cut, data = diamonds,mean)

# 각 cut과 color의 평균 price
aggregate(price~cut + color, data=diamonds, mean)

# 각 cut과 color의 평균 price ,carat
aggregate(cbind(price, carat) ~ cut + color, data=diamonds, mean)

###################################################
install.packages('plyr')
library(plyr)
data("baseball")
head(baseball)
str(baseball)   # 데이터 타입들 확인해보기

# 출루율OBP : On Base Percentage
# OBP =  h + bb + hbp / ab + bb + hbp + sf

# h = hits 안타
# bb = bases on balls 볼넷
# hbp = time hit by pitch 몸에 맞은 공
# ab = at bats 타수
# st = sacrifice flies 희생플라이 


# hbp가 NA인 경우 0으로 변경
baseball$hbp[is.na((baseball$hbp))] <- 0 

# sf가 NA인 경우 0으로 변경
baseball$sf[is.na((baseball$sf))] <- 0


head(baseball)
str(baseball)

# 타수ab가 50 이상인 데이터는 base에 저장
base <- baseball[ baseball$ab >= 50, ]  # 전체데이터에서 가져올것. 행을 가져올것이고 조건은 ab가 50이상인것.
base

# 출루율 계산 함수
obp_cal <- function(data){
  c(obp = with(data, sum (h + bb + hbp) / sum(ab + bb + hbp + sf)))

}

# base 데이터셋에 출루율 적용
obps <- ddply(base, .variables='id', .fun=obp_cal)
obps

#obps를 obp가 높은순으로 정렬하여 표시

# 행렬 정렬
obps [ order(obps[,2], decreasing = TRUE),]  
obps [ order(obps$obp, decreasing = TRUE),] 

#################################################
install.packages('dplyr')
# 데이터 처리 패키지
# filter( ) : 행 추출
# select( ) : 열 추출
# arrange( ) : 정렬
# mutate( ) : 변수 추가
# summarize( ) : 통계 요약
# group_by ( ) : 그룹화

library(dplyr)
library(ggplot2)

data("diamonds")
head(diamonds)


# 데이터가 많은 경우 tible 형태로 변환 작업
# - 모은 데이터 화면 출력 x
# - as_tible( )

str(diamonds)


#######################################
dia_tibb <- as_tibble(diamonds) # tibble 객체로 변환

#cut의 종류별로 정렬
dia_tibb <- arrange(dia_tibb,cut)
dia_tibb

# cut이 Ideal인 데이터 추출
dia_tibb <- filter(dia_tibb, cut=='Ideal')

# x, y, z 를 더해서 total 변수에 저장한 후 추가
dia_tibb <- mutate(dia_tibb, total=(x+y+z))
dia_tibb

############################################3
# 함수 chanin()  } $>%
# - %>% : 파이프연산자
# - 데이터셋관 연결하여 연산
# - 데이터셋 %>% 조건 또는 계산 %>% ~~
# 단축키 : Ctrl + shift + M

as_tibble(diamonds)%>% arrange(cut) %>% filter(cut=='Ideal')%>% mutate(xyz = (x+y+z))

###############################################
diamonds
#carat, price 열 추출
select(diamonds, carat, price)


#carat, price 제외한 열 추출
select(diamonds, -carat, -price)

diamonds%>%select(-carat, -price)

# cut이 Ideal이거나 Good인 데이터 추출
diamonds %>% filter(cut=='Ideal' | cut == 'Good')

diamonds %>% filter(cut %in% 'Ideal', 'Good')

# cut 별로 price 평균
diamonds %>% group_by(cut) %>% summarise(avg_price = mean(price))

# cut 별로 price, carat 평균
diamonds %>% group_by(cut) %>% summarise(avg_price = mean(price), avg_carat = mean(carat))

# merge( ) : 데이터 프레임 합치기
df1 <- data.frame(id=c('K','L', 'H'), city =c('Seoul','Pusan','Jeju'), age=c(10, 20, 30))
df2 <- data.frame(name=c('K','L', 'H','A'), class =c('A','B','C','D'), level=c(1, 2, 3, 4))

merge(df1, df2, by.x='id',by.y='name')   # 합칠 데이터 작성, 조인 조건 뒤에 작성 
merge(df1, df2, by.x='id',by.y='name',all=T)   # 합칠 데이터 작성, 조인 조건 뒤에 작성, outer join


####################################################
install.packages('wordcloud')
install.packages('RColorBrewer')
library(wordcloud)
library(RColorBrewer)


sns <- c('밴드','페이스북','인스타그램','트위터','카카오스토리','텔레그램','에브리타임','템프러','비트윈','스타일쉐어')

bindo <- c(28, 19, 18, 16, 5, 5, 3, 2, 2, 2)

display.brewer.all()   # 사용할 수 있는 컬러차트
colr <- brewer.pal(9, 'Set1')  # brewer.pal(색의 수, 팔레트 이름)  
wordcloud(sns,bindo,random.order = T, colors = colr)


# jeju_2022.csv 파일을 읽어서 jeju에 저장
# 데이터 구조 확인
jeju <- read.csv('jeju_2022.csv')

jeju

str(jeju)

# jeju$객실수가 chr 타입이었을시 as.integer(jeju$객실수) 해서 int타입으로 변경후 

wordcloud(jeju$상호명,jeju$객실수 ,random.color = T, colors = colr)

# 데이터가 많아 warning이 뜨기 때문에 할당된 숫자를 조정하는 방법
wordcloud(jeju$상호명,jeju$객실수 * 0.1 ,random.color = T, colors = colr)

# min.freq  최소빈도

wordcloud(jeju$상호명,jeju$객실수,random.color = T, colors = colr, min.freq = 100)

# scale 설정
wordcloud(jeju$상호명,jeju$객실수,random.color = T, colors = colr, scale=c(3, 0.3))

########################################################
install.packages('wordcloud2')
install.packages('rJava')

library(wordcloud2)
library(rJava)

data('demoFreq')
str(demoFreq)

head(demoFreq)
wordcloud2(demoFreq)

letterCloud(data=demoFreq,word = 'R',wordSize = 2)   # 실행 안된다. 컴퓨터 사양에 따라

# 지정한 모양에 wordcloud 적용하기
figPath = system.file('examples/t.png', package='wordCloud2')

wordcloud2(demoFreq, figPath = figPath , size=1.5)


#################################################
# 영어 지문에서 단어추출 빈도수수
install.packages('httr')
install.packages('rvest')
install.packages('XML')
install.packages('tm')
install.packages('stringr')

library(httr)
library(rvest)
library(XML)
library(NLP)
library(tm)
library(stringr)
library(wordcloud2)

speech_url = 'https://edition.cnn.com/2016/11/09/politics/donald-trump-victory-speech/index.html'

web_page <-read_html(speech_url)  # 웹페이지 읽어보기
web_page

html <- htmlParse(web_page,encoding = 'utf-8')  # html만가져오기기

p <- xpathSApply(html,"//p[@class='paragraph inline-placeholder']",xmlValue)   # p태그 가져오기
p
p <- tolower(p)    # 모두 소문자로 변경

p <-gsub('\n','', p)   # \n 제거
p <-gsub('\r', '' ,p) # \r 제거
p <-gsub('\t', '' ,p)  # \t 제거

p_txt <- Corpus(VectorSource(p)) # 말뭉치화
p_txt <- tm_map(p_txt,removeNumbers)   # 숫자 제거 
p_txt <- tm_map(p_txt,removePunctuation)   # 구두점 제거
p_txt <- tm_map(p_txt,stripWhitespace)   # 공백 제거
p_txt <- tm_map(p_txt,removeWords,stopwords('en'))   # 불용어 제거, 관사, 전치사 등

 # p_txt <- tm_map(p_txt,stemDocument) # 단어의 줄기 추출

p_mtx <- TermDocumentMatrix(p_txt) # 말뭉치 행렬화
p_mtx <- as.matrix(p_mtx)         # 행렬로 반환
p_mtx <- sort(rowSums(p_mtx), decreasing = T)   # 빈도수 내림차순 정렬
p_mtx <- data.frame(word=names(p_mtx), freq=p_mtx, stringsAsFactors = F) # 데이터프레임으로 변환

wordcloud2(p_mtx)

###############################################
# 한국 지문에서 한글 추출 빈도수
# install.packages('koNLP')  현재 버전에 지원안함. 그래서 다른 방법

install.packages('multilinguer')
library(multilinguer)
install.packages(c("hash", "tau", "Sejong", "RSQLite", 
                   "devtools", "bit", "rex", "lazyeval", 
                   "htmlwidgets", "crosstalk", "promises", 
                   "later", "sessioninfo", "xopen", "bit64", 
                   "blob", "DBI", "memoise", "plogr", "covr", 
                   "DT", "rcmdcheck", "rversions"), 
                 type = "binary")

install.packages('remotes')

remotes::install_github('haven-jeon/KoNLP', 
                        upgrade = "never", 
                        INSTALL_opts=c("--no-multiarch"))


install.packages('koNLP')
library(rJava)
library(KoNLP)    # 이 단계에서는 Checking user defined dictionary! 에러 그래서

useSejongDic()   # 이거 설치하고고
library(KoNLP)   # 다시 import

extractNoun('패키지 설치 테스트 중')

dokdo <- readLines('dokdo.txt')

nouns_list <- sapply(dokdo, extractNoun, USE.NAMES = F)
nouns_list

nouns <- unlist(nouns_list)

library(stringr)
# 단어 변경
nouns <- str_replace_all(nouns, '한국의', '한국')
nouns <- str_replace_all(nouns, '일본의', '일본')
nouns <- str_replace_all(nouns, '^독$', '독도')
nouns <- str_replace_all(nouns, '^일$', '일본')

# 단어 삭제

nouns <- str_remove_all(nouns, '을$|를$')
nouns <- gsub('^한$|^것$|^수$|^하$|^간$|^적$|^이$','삭제문자',nouns)

nouns <- str_remove(nouns,'삭제문자')
nouns

word_cnt <- table(nouns)
word_cnt <- sort(word_cnt,decreasing = T)
word_cnt <- as.data.frame(word_cnt,stringsAsFactors = F)
word_cnt


library(wordcloud2)
wordcloud2(word_cnt)
wordcloud2(word_cnt,shape = 'star')

##################################################
obama_url = 'https://www.chosun.com/site/data/html_dir/2009/01/21/2009012100180.html'

web_page <-read_html(obama_url)  # 웹페이지 읽어보기
web_page

html <- htmlParse(web_page,encoding = 'utf-8')  # html만가져오기기

p <- xpathSApply(html,"//section[@class='article-body']",xmlValue)  # p태그 가져오기
p

p <- tolower(p)    # 모두 소문자로 변경

p <-gsub('\n','', p)   # \n 제거
p <-gsub('\r', '' ,p) # \r 제거
p <-gsub('\t', '' ,p)  # \t 제거

p_txt <- Corpus(VectorSource(p)) # 말뭉치화
p_txt <- tm_map(p_txt,removeNumbers)   # 숫자 제거 
p_txt <- tm_map(p_txt,removePunctuation)   # 구두점 제거
p_txt <- tm_map(p_txt,stripWhitespace)   # 공백 제거
p_txt <- tm_map(p_txt,removeWords,stopwords('en'))   # 불용어 제거, 관사, 전치사 등

# p_txt <- tm_map(p_txt,stemDocument) # 단어의 줄기 추출

p_mtx <- TermDocumentMatrix(p_txt) # 말뭉치 행렬화
p_mtx <- as.matrix(p_mtx)         # 행렬로 반환
p_mtx <- sort(rowSums(p_mtx), decreasing = T)   # 빈도수 내림차순 정렬
p_mtx <- data.frame(word=names(p_mtx), freq=p_mtx, stringsAsFactors = F) # 데이터프레임으로 변환

wordcloud2(p_mtx)




