package market.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import market.util.DBConn;
import market.vo.BoardVO;
import market.vo.ProductVO;

public class BoardDAO {
	private Connection con;
	private PreparedStatement pstmt;
	private ResultSet rs;	
	private String query;		

	public BoardDAO(Connection con) {
		this.con = con;
	}
	
	//전체 게시물 목록 - 페이징
	public List<BoardVO> selectAll(double amount, int pageNum){
		List<BoardVO> bvoList = new ArrayList<>();
		BoardVO bvo = null;	
		try {
			query = " SELECT * "
					+ "FROM    (SELECT ROWNUM AS rnum, b.* "
					+ "         FROM   (SELECT * FROM board ORDER BY num DESC) b "
					+ "         WHERE  ROWNUM <= 5 * 1 ) "
					+ "WHERE  rnum > 5 * (1 - 1) ";

			query = " SELECT * "
					+ "FROM    (SELECT ROWNUM AS rnum, b.* "
					+ "         FROM   (SELECT * FROM board ORDER BY num DESC) b "
					+ "         WHERE  ROWNUM <= ? * ? ) "
					+ "WHERE  rnum > ? * ? ";
			
			pstmt = con.prepareStatement(query);
			pstmt.setDouble(1, amount);
			pstmt.setInt(2, pageNum);
			pstmt.setDouble(3, amount);
			pstmt.setInt(4, (pageNum - 1));

			rs = pstmt.executeQuery();
			while (rs.next() == true) {				 
				bvo = new BoardVO();
				bvo.setNum(rs.getInt("num"));
				bvo.setId(rs.getString("id"));	 
				bvo.setSubject(rs.getString("subject"));	
				bvo.setContent(rs.getString("content"));	 
				bvo.setRegDate(rs.getDate("reg_date"));
				bvo.setHit(rs.getInt("hit"));	 
				bvo.setIp(rs.getString("ip"));
				
				bvoList.add(bvo);  //List 객체에 추가
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstmt, rs);
		}
		return bvoList;
	}
	
	//게시물 하나 조회
	public BoardVO select(int num) { 
		BoardVO bvo = null;	
		try {
			query = " SELECT * FROM board WHERE num=?";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();
			if (rs.next() == true) {				 
				bvo = new BoardVO();
				bvo.setNum(rs.getInt("num"));
				bvo.setId(rs.getString("id"));	 
				bvo.setSubject(rs.getString("subject"));	
				bvo.setContent(rs.getString("content"));	 
				bvo.setRegDate(rs.getDate("reg_date"));
				bvo.setHit(rs.getInt("hit"));
				bvo.setIp(rs.getString("ip"));	 
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstmt, rs);
		}
		return bvo;
	}
	
	//게시물 조회 수 증가
	public void updateHit(int num) {
		try {
			query = " UPDATE board SET hit = hit + 1 WHERE num=?";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstmt);
		}
	}
	
	//전체 게시물 목록
	public List<BoardVO> selectAll(){
		List<BoardVO> bvoList = new ArrayList<>();
		BoardVO bvo = null;	
		try {
			query = " SELECT * FROM board ORDER BY num DESC";
			pstmt = con.prepareStatement(query);

			rs = pstmt.executeQuery();
			while (rs.next() == true) {				 
				bvo = new BoardVO();
				bvo.setNum(rs.getInt("num"));
				bvo.setId(rs.getString("id"));	 
				bvo.setSubject(rs.getString("subject"));	
				bvo.setContent(rs.getString("content"));	 
				bvo.setRegDate(rs.getDate("reg_date"));
				bvo.setHit(rs.getInt("hit"));	 
				bvo.setIp(rs.getString("ip"));
				
				bvoList.add(bvo);  //List 객체에 추가
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstmt, rs);
		}
		return bvoList;
	}
	
	//전체 게시물 수
	public int totalCount() {
		int cnt = 0;
		try {
			query = " SELECT COUNT(*) FROM board";
			pstmt = con.prepareStatement(query);

			rs = pstmt.executeQuery();
			if (rs.next() == true) {				 
				cnt = rs.getInt(1);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(pstmt, rs);
		}
		return cnt;
	}

	//게시물 등록
	public boolean insert(BoardVO bvo) {
		return true;//false;	 
	}
	
	//게시물 삭제

	public boolean delete(int num) {
		return true;//false;	 
	}
	
}


















