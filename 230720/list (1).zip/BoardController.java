package market.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import market.dao.BoardDAO;
import market.vo.BoardVO;

@WebServlet("*.do")
public class BoardController extends HttpServlet {
	private static final double AMOUNT_PER_PAGE = 5.0;	//한 페이지의 게시물 수
	private static final double NUM_PER_PAGE = 5.0; 	//한 페이지에 표시할 페이지 번호 수
	
	private static final long serialVersionUID = 1L;
	private HttpSession session;
	private BoardDAO bdao;
	private String url;
	
	public void init(ServletConfig config) throws ServletException {
		ServletContext servletCtx = config.getServletContext();
		Connection con = (Connection) servletCtx.getAttribute("con");
		bdao = new BoardDAO(con);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cmd = request.getRequestURI()
							.substring(request.getContextPath()
											  .length());
		session = request.getSession();
		
		//cmd에 따라 각 해당 메서드 호출
		if(cmd.equals("/BoardList.do")) 	{ list(request);			}
		if(cmd.equals("/BoardWriteForm.do")){ url = "/board/write.jsp";	}
		if(cmd.equals("/BoardWrite.do")) 	{ write(request);
											  response.sendRedirect(url);
											  return; 					}
		if(cmd.equals("/BoardView.do"))		{ view(request); 			}
		if(cmd.equals("/BoardRemove.do"))	{ remove(request);
											  response.sendRedirect(url);
											  return; 					}
		if(cmd.equals("/BoardModify.do"))	{ modify(request);
											  response.sendRedirect(url);
											  return; 					}
		
		RequestDispatcher rdp = request.getRequestDispatcher(url);
		rdp.forward(request, response);
	} 
			
	//게시판 글 하나 조회		/BoardView.do
	public void view(HttpServletRequest request) {
		int num = Integer.parseInt(request.getParameter("num"));
		String id = request.getParameter("id");
		String sid = (String)session.getAttribute("sid");
		
		if(sid == null || !sid.equals(id)) {
			bdao.updateHit(num);
		}

		request.setAttribute("bvo", bdao.select(num));
		url = "/board/view.jsp";
	}

	//게시판 수정			/BoardModify.do
	public void modify(HttpServletRequest request) {
		BoardVO bvo = new BoardVO();
		bvo.setNum(Integer.parseInt(request.getParameter("num")));
		bvo.setSubject(request.getParameter("subject"));
		bvo.setContent(request.getParameter("content"));
		
		if(bdao.insert(bvo)) {
			session.setAttribute("msg", "게시물이 수정되었습니다.");
		} else { 
			session.setAttribute("msg", "게시물 수정에 실패했습니다.");
		}
		url="./BoardList.do";
	}
	
	public void remove(HttpServletRequest request) {
		int num = Integer.parseInt(request.getParameter("num"));
		if(bdao.delete(num)) {	session.setAttribute("msg", "게시물이 삭제되었습니다.");
		} else { 				session.setAttribute("msg", "게시물 삭제에 실패했습니다.");		}
		url="./BoardList.do";
	}
	
	public void write(HttpServletRequest request) {
		BoardVO bvo = new BoardVO();
		bvo.setId(request.getParameter("id"));
		bvo.setSubject(request.getParameter("subject"));
		bvo.setContent(request.getParameter("content"));
		bvo.setIp(request.getRemoteAddr());
		
		if(bdao.insert(bvo)) {
			session.setAttribute("msg", "게시물이 등록되었습니다.");
		} else { 
			session.setAttribute("msg", "게시물 등록에 실패했습니다.");
		}

		url="./BoardList.do";
	}

	//게시판 목록 조회		
	public void list(HttpServletRequest request) {
		int pageNum = Integer.parseInt(request.getParameter("pageNum"));
		int totalCnt = bdao.totalCount();
		int pages = (int)(Math.ceil(totalCnt/AMOUNT_PER_PAGE)); 
		
		//각 페이지의 시작 번호 | ... | 끝 번호
		int end 	= (int)(Math.ceil(pageNum/NUM_PER_PAGE) * NUM_PER_PAGE); 
		int start 	= end - (int)(NUM_PER_PAGE - 1);
		    end  	= end >= pages ? pages : end; 
		    
		//이전 | 이후 버튼 활성화 여부
		boolean prev = start > 1;
		boolean next = end < pages;
		    
		request.setAttribute("boardList", bdao.selectAll(AMOUNT_PER_PAGE, pageNum));  
		request.setAttribute("totalCnt", totalCnt); //  
		request.setAttribute("pageNum", pageNum); 
		request.setAttribute("pages", pages); 
		request.setAttribute("end", end); 
		request.setAttribute("start", start); 
		request.setAttribute("prev", prev); 
		request.setAttribute("next", next); 
		
		url = "/board/list.jsp";
	}
	
}


















