package market.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import market.util.DBConn;
import market.vo.MemberVO;

public class MemberDAO {
	private Connection con;
	private String query; // 쿼리문 저장 필드
	private PreparedStatement psmt;
	private ResultSet rs;
	
	public Connection getCon() {
		return con;
	}

	public void setCon(Connection con) {
		this.con = con;
	}
	
	
	// 회원 인증
	public boolean isMember(MemberVO mvo){
		
		
		return false;
		
	}
	
	
	
	
	
	// 회원 등록
	public boolean insert(MemberVO mvo) {
		try { // 쿼리를 실행하다가 예외가 발생할 수 있으니까 try/ catch문에다가 // insert 쿼리문
			query = " INSERT INTO member VALUES (?, ?, ?, ?, ?,SYSDATE)"; // 이미지가 null이면 default 이미지를
																							// 넣고 아니면 선택 이미지 넣기

			// 매개변수로 넘겨받은 데이터를 product 테이블에 저장
			psmt = con.prepareStatement(query);

			psmt.setString(1, mvo.getId());
			psmt.setString(2, mvo.getPw());
			psmt.setString(3, mvo.getName());
			psmt.setString(4, mvo.getPhone());
			psmt.setString(5, mvo.getEmail());

			int result = psmt.executeUpdate();

			if (result == 1) { // 정상적으로 회원가입 성공 시 true 반환
				return true;
				// 여기서 메시지를 보낸다. logoutProc를 참고
				// session에 저장?
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(psmt);
		}

		// 그렇지 않으면 false 반환
		return false;   // 여기서 메시지를 보낸다.

	} // insert end
	
}
