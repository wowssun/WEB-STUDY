package market.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import market.util.DBConn;
import market.vo.BoardVO;

public class BoardDAO {
	
	private Connection con;
	private String query;	   // 쿼리문 저장 필드
	private PreparedStatement psmt;
	private ResultSet rs;

	public BoardDAO(Connection con) {   // memberDAO에서는 setter,getter로 이제는 생성자로
		this.con = con;
	}
	
	// 전체 게시물 목록
	
	public List<BoardVO> selectAll(){
		
		List<BoardVO> bvoList = new ArrayList<BoardVO>();
		
		BoardVO bvo = null;
		
		try {
			query = "SELECT * FROM board";
			psmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
			 //psmt = con.prepareStatement(query);
			
			rs = psmt.executeQuery();
			
			while(rs.next()) {   //. 여러 줄이니까 while 
				
				bvo = new BoardVO();   //  BoardVO 객체를 생성하여 
				bvo.setNum(rs.getInt("num"));						//  해당 레코드 값을 저장
				bvo.setId(rs.getString("id"));
				bvo.setSubject(rs.getString("subject"));
				bvo.setRegDate(rs.getDate("reg_date"));	
				bvo.setHit(rs.getInt("hit"));
				bvo.setIp(rs.getString("ip"));
		
			bvoList.add(bvo);	// bvoList 객체에 추가
			}
		}catch (SQLException e) {
  			e.printStackTrace();
  		}finally { 
  		 DBConn.close(rs, psmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
  		}	
		return bvoList;
		
		
	}
	
	// 전체 게시물 수
	
	public int totalCount() {   
		
		int cnt = 0;
		
		try {
			query = "SELECT COUNT(*) FROM board";
		       
		    psmt = DBConn.getConnection().prepareStatement(query);
			// psmt = con.prepareStatement(query);
			 
			 rs = psmt.executeQuery();
		      
		      if (rs.next()) {
		    	cnt = rs.getInt(1);
			}
		}catch (SQLException e) {
  			e.printStackTrace();
  		}finally { 
  		 DBConn.close(rs, psmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
  		}			
		
		return cnt;
	}
	
	// 게시물 등록하기 (글쓰기)
	public boolean insert(BoardVO bvo) {
		 try {  // 쿼리를 실행하다가 예외가 발생할 수 있으니까 try/ catch문에다가 	// insert 쿼리문
			   query = " INSERT INTO board VALUES ( board_seq.NEXTVAL, ? ,? ,? ,SYSDATE ,0 ,? )";  // dao 쿼리문 수정 다시하기
			   // INSERT INTO board VALUES ( board_seq.NEXTVAL, 'aaa','aaa' , 'aaa', sysdate,0,'aaa');  // 여기서 4개의 값만 입력받으면 됨
			   // 여기서 hit는 그냥 0으로 처리해놓는다.
			   
			 
			   psmt = DBConn.getConnection().prepareStatement(query);
			   
			   //(작성자,제목,내용,사용자ip)
			   
			   psmt.setString(1, bvo.getId());
			   psmt.setString(2, bvo.getSubject());
			   psmt.setString(3, bvo.getContent());
			   psmt.setString(4, bvo.getIp());
			  
			   
			   int result = psmt.executeUpdate();
			 
			   if(result ==1) {   // 정상적으로 게시글 등록 시 true 반환
				  return true; }
		  		} catch (SQLException e) {
		  			e.printStackTrace();
		  		}finally {   
		  		 DBConn.close(psmt);
		  		}
		  		// 그렇지 않으면  false 반환
		  		return false;
	}

}
