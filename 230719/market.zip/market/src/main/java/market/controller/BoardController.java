package market.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import market.dao.BoardDAO;
import market.vo.BoardVO;


@WebServlet("*.do")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HttpSession session;   // 서블릿은 내장객체가 아니라서 session을 선언하고 사용하여야 한다.
							       //  로그인한 사람만 게시판에 글쓰게 하려고
	private BoardDAO bdao;
	private String url;

	public void init(ServletConfig config) throws ServletException {
		
		ServletContext servletCtx = config.getServletContext();
		Connection con = (Connection) servletCtx.getAttribute("con");
	
		 bdao = new BoardDAO(con);
	
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cmd =request.getRequestURI().substring(request.getContextPath().length());  // market/BoardList.do
		// 원래 이렇게 뜨지만 /market을 자르는 것.
		
		session = request.getSession();  // 내장객체가 아니기 때문에 선언하고 써야한다.
		
		// cmd가 /BordList.do인 경우 게시판 목록 조회 메서드 호출
		if(cmd.equals("/BoardList.do")) {
			list(request);
		}
		if(cmd.equals("./BoardWirteForm.do")) {
			 url ="/board/write.jsp";
		}
		if(cmd.equals("./BoardWirte.do")) {
			write(request);
			response.sendRedirect("./BoardWirte.do");	// write를 하고 나서는 redirect로 boardwrite.do 처리해야한다.( 이건 위에서 처리하기)
			 return; 									// return이 없으면 밑에 forward가 실행되기 때문에 return을 해서 중단시키는것.
		}
		RequestDispatcher rdp = request.getRequestDispatcher(url);
		rdp.forward(request, response);
	}

	// 게시판 글쓰기	 		/ BoardWrite.do
	private void write(HttpServletRequest request) {
		 BoardVO bvo = new BoardVO(); // boardvo 객체 생성
		bvo.setId(request.getParameter("id"));//bvo.setId(request.getParameter("")//vo.setIp(request.getremoteAddr)	
		bvo.setSubject(request.getParameter("subject"));
		bvo.setContent(request.getParameter("content"));   // 넘어오는 값(작성자,제목,내용,사용자ip)을 vo에 담고 담아서 dao로 호출하고
		bvo.setIp(request.getRemoteAddr());
		
		
		if(bdao.insert(bvo)){
			 session.setAttribute("msg", "게시물이 등록되었습니다.");
		}else{
			session.setAttribute("msg", "게시물 등록에 실패했습니다.");
		}		
		
	}

	// 게시판 목록 조회  / BoardList.do
	public void list(HttpServletRequest request) {
	 request.setAttribute("boardList", bdao.selectAll());   // 조회 list dao에서 호출하고 반환되는 값을 요청객체에 담는다.
	 request.setAttribute("totalCnt", bdao.totalCount());	// 숫자 totalConunt request속성에 담는다?
		
	 url ="/board/list.jsp";
		
	}

	
	// 게시판 수정		        / BoardModify.do
	// 게시판 삭제		        / BoardRemove.do
	// 게시판 글 하나 조회	    / BoardView.do

}
