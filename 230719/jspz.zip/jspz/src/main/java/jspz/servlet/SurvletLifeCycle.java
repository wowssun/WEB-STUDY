package jspz.servlet;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/SurvletLifeCycle.do")
public class SurvletLifeCycle extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public SurvletLifeCycle() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("서블릿 시작 init()...");
	}

	
	public void destroy() {
		System.out.println("톰캣 종료 destroy()...");
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("서블릿 작동 중 service()...");
	}

}
