package jspz.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet Filter implementation class MemberFilter
 */
@WebFilter("/member/*")   
public class MemberFilter extends HttpFilter implements Filter {


	private static final long serialVersionUID = 1L;

	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
	//	System.out.println("MemberFilter");
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse)response;
		HttpSession session = req.getSession();
		
		//로그인 하지 않은 경우
		String sid = (String)session.getAttribute("sid");  
		 if(sid ==null){  
			 req.setAttribute("msg","회원 전용 메뉴입니다. 로그인 후 이용해주세요.");   // 요청 객체의 msg 속성에 "회원 전용 메뉴입니다. 로그인 후 이용해주세요." 를 저장
			 RequestDispatcher rdp = req.getRequestDispatcher("/exercise/login.jsp"); // 로그인 페이지로
			rdp.forward(req, res);
		
		// 그렇지 않은 경우
		 }else{
			// System.out.println("MemberFilter - login o ");
			 chain.doFilter(request, response);
		 }
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
