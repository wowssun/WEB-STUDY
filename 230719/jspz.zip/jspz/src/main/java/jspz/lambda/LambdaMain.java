package jspz.lambda;

// 1. Thread 클래스를 상속받는 ThreadA 작성
class ThreadA extends Thread {
	public void run() {
		System.out.println("This is the ThreadA");

	}
}

// 2. Runnable 인터페이스를 구현하는 ThreadB 클래스 작성
class RunnableB implements Runnable {

	@Override
	public void run() {
		System.out.println("This is the RunnableB");
	}
}

// 매개변수 X, 반환값 x 추상 메서드 method를 InterfceA 인터페이스 작성
@FunctionalInterface
interface InterfaceA { // 반환 x , 매개변수 x
	public void method();
}

@FunctionalInterface
interface InterfaceB { // 반환 x, 매개변수 o
	public void method(int x);
}

@FunctionalInterface
interface InterfaceC { // 반환 o , 매개변수 x
	public double method();
}

@FunctionalInterface
interface InterfaceD { // 반환 o , 매개변수 2
	public double method(int x, int y);
}

// InterfaceA를 구현하는 ClassA작성
// 부모 메서드 오버라이딩 : "This is the ClassA"출력
class ClassA implements InterfaceA {

	@Override
	public void method() {
		System.out.println("This is the ClassA");

	}

}

public class LambdaMain {
	
	public void printName(String name) {
		System.out.println("name : " + name);
	}

	public static void main(String[] args) {

		Thread t = new ThreadA(); // 부모 t = new 자식
		t.start();

		// -----------------------------------------

		Runnable r = new RunnableB();
		// r.start(); x
		Thread t2 = new Thread(r); // O
		t2.start();

		// -----------------------------------------

		// 3. 익명의 객체로 Thread 구현
		Thread t3 = new Thread() {
			public void run() {
				System.out.println("This is the ThreadC");
			}
		};
		t3.start();

		new Thread(new Runnable() { // 참조변수가 없는 타입

			@Override
			public void run() {
				System.out.println("This is the RunnableD");
			}
		}).start();

		// 람다식
		new Thread(() -> System.out.println("This is the Lambda")).start();

		InterfaceA a = new ClassA();
		a.method();

		InterfaceA b = new InterfaceA() {
			@Override
			public void method() {
				System.out.println("This is the ClassA 2");
			}
		};
		b.method();

		InterfaceA c = () -> {
			System.out.println("This is the ClassA lambda 1");
		};
		c.method();

		InterfaceA cc = () -> {
			System.out.println("This is the ClassA lambda 2");
		};
		cc.method();

		InterfaceB ib = (arg) -> {
			int result = arg * 2;
			System.out.println("2 *2 = " + result);

		};
		ib.method(2);

		ib = (arg) -> System.out.println("2 * 2 = " + arg * 2);
		ib.method(2);

		ib = arg -> System.out.println("2 * 2 = " + arg * 2);
		ib.method(2);

		InterfaceC ic = () -> {
			double pi = 3.14;
			return pi;
		};
		System.out.println("return pi : " + ic.method());

		ic = () -> 3.14;
		System.out.println("return piii : " + ic.method());

		InterfaceD id = (arg1, arg2) -> {
			int result = arg1 + arg2;
			return result;
		};

		System.out.println("return 1 + 2 : " + id.method(1, 2));

		id = (arg1, arg2) -> {
			return arg1 + arg2;
		};
		System.out.println("return 3 + 4 : " + id.method(3, 4));

		id = (arg1, arg2) -> arg1 + arg2;
		System.out.println("return 3 + 4 : " + id.method(5, 6));
	}
}
