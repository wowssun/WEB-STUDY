package jspz.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Survey.do")
public class SurveyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");  // 한글 전송시 깨지는거 방지
		
		PrintWriter out = response.getWriter();
		
		out.print("<html><head><title>Survey Servlet</title></head>");
		out.print("<body><h1>Survey done!</h1></body></html>");
		
		String one = request.getParameter("one");
		String two = request.getParameter("two");
		String sam = request.getParameter("sam");
		
	   System.out.println("top 1 : " + one);
	   System.out.println("top 2 : " + two);
	   System.out.println("top 3 : " + sam);
	}

}
