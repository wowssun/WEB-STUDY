package jspz.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

//@WebListener
public class SimpleListenter implements HttpSessionListener, ServletContextListener, ServletRequestListener {

   
    public SimpleListenter() {
    	System.out.println("SimpleListener default constructor()");
    }
      

	
    public void sessionCreated(HttpSessionEvent se)  { 
    	System.out.println("SimpleListener sessionCreated()");
    }

	
    public void requestDestroyed(ServletRequestEvent sre)  { 
    	System.out.println("SimpleListener requestDestroyed()");
    }


    public void requestInitialized(ServletRequestEvent sre)  { 
    	System.out.println("SimpleListener requestInitialized()");
    }

	
    public void sessionDestroyed(HttpSessionEvent se)  { 
    	System.out.println("SimpleListener sessionDestroyed()");
    }

	
    public void contextDestroyed(ServletContextEvent sce)  { 
    	System.out.println("SimpleListener contextDestroyed()");
    }

    public void contextInitialized(ServletContextEvent sce)  { 
    	System.out.println("SimpleListener contextInitialized()");
    }
	
}
