package jejuOseyo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jejuOseyo.util.DBConn;
import jejuOseyo.vo.CartVO;
import market.vo.BoardVO;

public class CartDAO {
	
	private Connection con;
	private String query;	   // 쿼리문 저장 필드
	private PreparedStatement psmt;
	private ResultSet rs;
	
	
	public CartDAO(Connection con) {
		this.con = con;
	}

	//장바구니 담기 (등록)
	public boolean cartInsert(CartVO cvo) {
		return false;
	} 
	
	//장바구니 전체 목록(페이징)
	public List<CartVO> cartSelectAll(double amount,int pageNum){
		List<CartVO> cvoList = new ArrayList<CartVO>();
		
		CartVO cvo = null;
		
		try {
			query = " select * from (select rownum as rnum,b.*"
				  + " from (select * from board ";
			if(!type.equals("") && !keyword.equals("")) {
				query += " where " + type + " like '%" + keyword + "%' ";
			}
				query +=" order by num desc) b"
					  + " where rownum <= ? * ?)"
					  + " where rnum > ? * ? ";
			
			
				psmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
				//psmt = con.prepareStatement(query);
			
			  psmt.setDouble(1, amount);
			  psmt.setInt(2, pageNum);
			  psmt.setDouble(3, amount);
			  psmt.setInt(4, (pageNum -1));
			
			
			  rs = psmt.executeQuery();
			
			
			while(rs.next()) {   //. 여러 줄이니까 while 
				
				cvo = new CartVO();   //  MemberVO 객체를 생성하여 
				cvo.setNum(rs.getInt("num"));						//  해당 레코드 값을 저장
				cvo.setId(rs.getString("id"));
				cvo.setSubject(rs.getString("subject"));
				cvo.setRegDate(rs.getDate("reg_date"));	
				cvo.setHit(rs.getInt("hit"));
				cvo.setIp(rs.getString("ip"));
		
				cvoList.add(cvo);	// list 객체에 추가
			}
		}catch (SQLException e) {
  			e.printStackTrace();
  		}finally { 
  		 DBConn.close(rs, psmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
  		}	
		return cvoList;
	} 
	
	//결제 전 예약 정보조회
	public CartVO cartSelect(int cno){
		CartVO cvo = null;
		return cvo;
		
	} 
	
	//장바구니 삭제
	public boolean cartDelete(int cno){
		try {
			query = "DELETE FROM CART WHERE cno = ? ";

			psmt = DBConn.getConnection().prepareStatement(query);
			psmt.setInt(1, cno);

			int result = psmt.executeUpdate();

			if (result == 1) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(psmt);
		}
		// 그렇지 않으면 false 반환
		return false;
	}
	
	 //장바구니 비우기
	public boolean cartDeleteAll(String mid){
		try {
			query = "DELETE FROM CART WHERE mid = ? ";

			psmt = DBConn.getConnection().prepareStatement(query);
			psmt.setString(1, mid);

			int result = psmt.executeUpdate();

			if (result == 1) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(psmt);
		}
		// 그렇지 않으면 false 반환
		return false;
	} 
	

}
