package jejuOseyo.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jejuOseyo.dao.CartDAO;
import jejuOseyo.dao.YeyakDAO;



@WebServlet("/cart/*")   // 그럼 /cart/ 뒤에 오는게 모두 여기 controller로
public class CaYeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HttpSession session;   // 서블릿은 내장객체가 아니라서 session을 선언하고 사용하여야 한다.
									//  로그인한 사람만 게시판에 글쓰게 하려고
	
	private CartDAO cdao;
	private YeyakDAO ydao;
	private String url;
	
	private static final double AMOUNT_PER_PAGE = 10.0; // 한 페이지의 게시물 수
	private static final double NUM_PER_PAGE = 5.0; // 한 페이지에 표시할 페이지 번호 수
	
    
    	public void init(ServletConfig config) throws ServletException {
		
			ServletContext servletCtx = config.getServletContext();
			Connection con = (Connection) servletCtx.getAttribute("con");
		
			cdao = new CartDAO(con);
			ydao = new YeyakDAO(con);
	
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String cmd =request.getRequestURI().substring(request.getContextPath().length());   // /cart/cartList.jsp
		System.out.println(cmd);
		session = request.getSession(); // 내장객체가 아니기 때문에 선언하고 써야한다.
		
		
		if(cmd.equals("/cart/cartList.do")) {
			cartList(request);
		}
		
		if(cmd.equals("/cart/cartRemove.do")) {
			cartRemove(request);
		}
		
		if(cmd.equals("/cart/cartRemoveAll.do")) {
			cartRemoveAll(request);
		}
		
		
	}

		// 장바구니 담기 (등록)
		public void cartDamgi(HttpServletRequest request) {}
		
		// 장바구니 전체 목록 /cartlist.do
		public void cartList(HttpServletRequest request) {
			
				
			
		}
		
		// 결제 전 예약 정보조회 /CartView.do
		public void cartView(HttpServletRequest request) {}
		
		// 장바구니 삭제  /cart/remove.do
		public void cartRemove(HttpServletRequest request) {
			
			
		}
		
		// 장바구니 비우기 /cart/removeAll.do
		public void cartRemoveAll(HttpServletRequest request) {
			
			
			
		}
		
		// 예약등록  /YeyakHagi.do
		public void yeyakHagi(HttpServletRequest request) {}
		
		// 예약전체목록 /YeyakList.do
		public void yeyakList(HttpServletRequest request) {}
		
		// 예약 확인/취소 상세 조회 /YeyakView.do
		public void yeyakView(HttpServletRequest request) {}
		
		// 예약 가능상태 수정 /YeyakModify.do
		public void yeyakModify(HttpServletRequest request) {}
}
