package jejuOseyo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jejuOseyo.util.DBConn;
import jejuOseyo.vo.CartVO;
import jejuOseyo.vo.HostVO;
import jejuOseyo.vo.MemberVO;
import jejuOseyo.vo.PaymentVO;
import jejuOseyo.vo.RoomVO;
import jejuOseyo.vo.YeyakVO;

public class YeyakDAO {
	
	private Connection con;
	private String query;	   // 쿼리문 저장 필드
	private PreparedStatement psmt;
	private ResultSet rs;
	
	public YeyakDAO(Connection con) {
		this.con = con;
	}

	// 예약등록
	public boolean yeInsert(YeyakVO yvo) {
		return false;
	}
	
	// 회원예약전체목록(페이징)
	public List<YeyakVO> yeSelectAll(double amount,int pageNum, String mid) {
		List<YeyakVO> yvoList = new ArrayList<YeyakVO>();
		

		YeyakVO yvo = null;
		RoomVO rvo = null;
		
		try {
			query = " SELECT * FROM (SELECT rownum as rnum,b.*"
				  + " FROM (SELECT r.img, r.rm_name, r.price, y.yno,y.ye_checkin, y.ye_checkout, y.ye_guest"
				  + " FROM yeyak y"
				  + " JOIN room r"
				  + " ON y.rm_no = r.rm_no"
				  + " WHERE mid = ?"
				  + " ORDER BY y.ye_checkin DESC) b"
				  + " WHERE rownum <= ? * ?)"
				  + " WHERE rnum > ? * ? ";
			
				psmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
				//psmt = con.prepareStatement(query);
			
				  psmt.setString(1, mid);
				  psmt.setDouble(2, amount);
				  psmt.setInt(3, pageNum);
				  psmt.setDouble(4, amount);
				  psmt.setInt(5, (pageNum -1));
				
			
				  rs = psmt.executeQuery();
			
			// r.img, r.rm_name, r.price,y.ye_checkin, y.ye_checkout, y.ye_guest"
			while(rs.next()) {   //. 여러 줄이니까 while 
				
				yvo = new YeyakVO(); //  YeyakVO 객체를 생성하여 
				rvo = new RoomVO();   //  RoomVO 객체를 생성하여 
				
				rvo.setImg(rs.getString("img"));// 숙소 이미지
				rvo.setRmName(rs.getString("rm_name"));// 숙소명
				rvo.setPrice(rs.getInt("price"));// 숙소 가격
				yvo.setYno(rs.getString("yno"));	// 예약번호
				yvo.setYeCheckIn(rs.getString("ye_checkin").substring(0,10));// 예약 체크인
				yvo.setYeCheckOut(rs.getString("ye_checkout").substring(0,10));// 예약 체크아웃
				yvo.setYeGuest(rs.getInt("ye_guest"));// 예약 인원수
				
				
				yvo.setRvo(rvo);							// rvo에 저장된 값을 cvo에 set
				
				yvoList.add(yvo);	// list 객체에 추가
			}
		}catch (SQLException e) {
  			e.printStackTrace();
  		}finally { 
  		 DBConn.close(rs, psmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
  		}	
		return yvoList;
	} 
	
	
	// 호스트예약전체목록(페이징)
		public List<YeyakVO> hoyeSelectAll(double amount,int pageNum, String hid) {
			List<YeyakVO> yvoList = new ArrayList<YeyakVO>();
			

			YeyakVO yvo = null;
			RoomVO rvo = null;
				
			try {
				query = " SELECT * FROM (SELECT rownum as rnum,b.*"
						  + " FROM (SELECT r.img, r.rm_name, r.price, y.yno,y.ye_checkin, y.ye_checkout, y.ye_guest"
						  + " FROM yeyak y"
						  + " JOIN room r"
						  + " ON y.rm_no = r.rm_no"
						  + " WHERE r.hid = ?"
						  + " ORDER BY y.ye_checkin DESC) b"
						  + " WHERE rownum <= ? * ?)"
						  + " WHERE rnum > ? * ? ";
				
					psmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
					//psmt = con.prepareStatement(query);
				
					  psmt.setString(1, hid);
					  psmt.setDouble(2, amount);
					  psmt.setInt(3, pageNum);
					  psmt.setDouble(4, amount);
					  psmt.setInt(5, (pageNum -1));
					
				
					  rs = psmt.executeQuery();
				
				
				while(rs.next()) {   //. 여러 줄이니까 while 
					
					yvo = new YeyakVO(); //  YeyakVO 객체를 생성하여 
					rvo = new RoomVO();   //  RoomVO 객체를 생성하여 
					
					rvo.setImg(rs.getString("img"));// 숙소 이미지
					rvo.setRmName(rs.getString("rm_name"));// 숙소명
					rvo.setPrice(rs.getInt("price"));// 숙소 가격
					yvo.setYno(rs.getString("yno"));	// 예약번호
					yvo.setYeCheckIn(rs.getString("ye_checkin").substring(0,10));// 예약 체크인
					yvo.setYeCheckOut(rs.getString("ye_checkout").substring(0,10));// 예약 체크아웃
					yvo.setYeGuest(rs.getInt("ye_guest"));// 예약 인원수
					
					yvo.setRvo(rvo);							// rvo에 저장된 값을 yvo에 set
					
					yvoList.add(yvo);	// list 객체에 추가
				}
			}catch (SQLException e) {
	  			e.printStackTrace();
	  		}finally { 
	  		 DBConn.close(rs, psmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
	  		}	
			return yvoList;
		} 
	
	// 회원 예약 확인/취소 상세 조회
	public YeyakVO yeSelect(String yno) {
		
		YeyakVO yvo = null;
		MemberVO mvo = null;
		HostVO hvo = null;
		RoomVO rvo = null;
		PaymentVO pvo = null;
		
		try {
			query = " SELECT y.yno,m.name,m.mphone,h.hnick,h.hphone,r.notice,r.rm_name,r.addr1, r.addr2, y.ye_guest,y.ye_checkin,y.ye_checkout,r.price,p.payno,p.card_name,p.card_num,p.pay_date,p.pay_candate"
				  + " FROM yeyak y"
				  + " JOIN j_member m"
				  + " ON y.mid = m.mid"
				  + " JOIN host h"
				  + " ON y.hid = h.hid"
				  + " JOIN room r"
				  + " ON y.rm_no = r.rm_no"
				  + " JOIN payment p"
				  + " ON y.payno = p.payno"
				  + " WHERE y.yno = ?";   
						
			psmt = DBConn.getConnection().prepareStatement(query);// 실행할 prepared
			
			psmt.setString(1,yno); // 물음표 바인딩   // 여기서 넘어온 mid
			
			rs = psmt.executeQuery();  // 실행한다.  executeQuery 는 resultSet 으로 온다. 그래서 int로 받을 수 없다. 결과가 있기 때문에 
			
			
			if(rs.next()) {		// 조회된 레코드가 있다면  // == true 기본
				
				yvo = new YeyakVO();   //  YeyakVO 객체를 생성하여 
				rvo = new RoomVO();   //  RoomVO 객체를 생성하여 
				mvo = new MemberVO();	// MemberVO 객체를 생성하여 
				hvo = new HostVO();
			    pvo = new PaymentVO();
				
				//  y.yno,m.name,m.mphone,h.hnick,h.hphone,r.notice,r.rm_name,r.addr1, r.addr2, y.ye_guest,y.ye_checkin,y.ye_checkout,r.price,
			    // p.payno,p.card_name,p.card_num,p.pay_date,p.pay_candate
				yvo.setYno(rs.getString("yno"));
				mvo.setName(rs.getString("name"));			// 예약자
				mvo.setMphone(rs.getString("mphone"));		// 예약자 전화번호
				hvo.setHnick(rs.getString("hnick"));	    // 호스트 닉네임
				hvo.setHphone(rs.getString("hphone"));      // 호스트 전화번호
				rvo.setNotice(rs.getString("notice"));		// 숙소 공지사항
				rvo.setRmName(rs.getString("rm_name"));  	// 숙소명
				rvo.setAddr1(rs.getString("addr1"));	    // 숙소 위치1
				rvo.setAddr2(rs.getString("addr2"));		// 숙소 위치 2
				rvo.setPrice(rs.getInt("price"));			// 숙소 가격
				yvo.setYeCheckIn(rs.getString("ye_checkin").substring(0,10));// 예약 체크인
				yvo.setYeCheckOut(rs.getString("ye_checkout").substring(0,10));// 예약 체크아웃
				yvo.setYeGuest(rs.getInt("ye_guest"));// 예약 인원수
				pvo.setPayNo(rs.getString("payno"));		// 결제번호
				pvo.setCardName(rs.getString("card_name"));  // 카드이름
				pvo.setCardNum(rs.getString("card_num"));    // 카드번호
				pvo.setPayDate(rs.getString("pay_date"));   // 결제일시
				pvo.setPayCanDate(rs.getString("pay_candate"));    // 결제취소 일시
				
				yvo.setMvo(mvo);
				yvo.setRvo(rvo);
				yvo.setHvo(hvo);
				yvo.setPvo(pvo);
				
				
			}
			}catch (SQLException e) {
	  			e.printStackTrace();
	  		}finally { 
	  			DBConn.close(rs, psmt);
	  		 
	  		}
		return yvo;
		
	} 
	
	// 호스트 예약 확인/취소 상세 조회
	public YeyakVO hoyeSelect(String yno) {
		YeyakVO yvo = null;
		
		return yvo;
		
	}
	
	// 예약 취소 (예약여부, 취소일시가 추가된다. ///////체크아웃지나고 다시 예약 가능한 상태로)
	public boolean yeUpdate(YeyakVO yvo) {
		
		//예약 여부 바꿔주는거랑 취소일시 update됨
		return false;
	} 

}
