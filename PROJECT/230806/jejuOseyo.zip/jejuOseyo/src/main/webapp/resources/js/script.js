// /resources/js/script.js

// 장바구니 삭제
function cartRemove(cno){

		if(confirm('장바구니에서 삭제하시겠습니까?')){
			location.href='./cartRemove.do?cno='+ cno;
			// cartRemove.do로 보내야함
			// cno를 가지고 어떻게 할것인가.
			// 이렇게 보내면 되는거징~~
		}
					
	}// if end

// 장바구니 비우기
function cartRemoveAll(){

		if(confirm('장바구니를 비우시겠습니까?')){
			location.href='./cartRemoveAll.do';
			// 그럼 얘도 똑같이?
			// 장바구니 비우기는 세션에 저장되어 있는 아이디로 지우면 되니까
			// 따로 파라미터는 안보내고 알림창 확인을 누르면 cartRemoveAll.do로 이동
		}
					
	}// if end
	
	
// 예약하러 가기
function yeyak(rmName,cno,pageNum){

		if(confirm('< ' + rmName + ' >' + '\n 예약하시겠습니까?')){
			
			location.href='./cartView.do?cno=' + cno + '&pageNum=' + pageNum;
		}
		
			
			// 그럼 얘도 똑같이?
			// 장바구니 비우기는 세션에 저장되어 있는 아이디로 지우면 되니까
			// 따로 파라미터는 안보내고 알림창 확인을 누르면 cartRemoveAll.do로 이동
		
					
	}// if end