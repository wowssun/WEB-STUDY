package market.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import market.util.DBConn;
import market.vo.ProductVO;

public class productDAO {
	
	private Connection con;
	private String query;	   // 쿼리문 저장 필드
	private PreparedStatement psmt;
	private ResultSet rs;
	private boolean result;	// DML처리 결과 여부 저장
	
	// 기본 생성자 - con 객체 초기화
	public productDAO() {
		this.con = DBConn.getConnection();
	}
	
	// 제품 등록
	 public boolean insert(ProductVO pvo)  { 
		 
		  		return result;
		  
	  } // insert end  
	 
	// 제품 수정
	public boolean update(ProductVO pvo) {
		
		  		return result;	  
		
	}
	
	// 제품 삭제
	public boolean delete(String pid) {   
		 
			  		return result ;	   
				  
	}
	
	// 제품 상세 조회
	public ProductVO select(String pid) {  
		 
  		return null ;	   
	  
}
	
	// 제품 전체 조회
	public List<ProductVO> selectAll(){ 
		
		List<ProductVO>proList = new ArrayList<ProductVO>();
		
		ProductVO pvo = null;
		
		try {
			query = "SELECT * FROM product";
			psmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
			
			rs = psmt.executeQuery();
			
			while(rs.next()) {   //. 여러 줄이니까 while 
				pvo = new ProductVO();   //  MemberVO 객체를 생성하여 
				pvo.setPimage(rs.getString("pimage"));
				pvo.setPname(rs.getString("pname"));
				pvo.setDescription(rs.getString("description"));						//  해당 레코드 값을 저장
				pvo.setPrice(rs.getInt("price"));	
				
				proList.add(pvo);	// list 객체에 추가
			}
		}catch (SQLException e) {
  			e.printStackTrace();
  		}finally { 
  		 DBConn.close(rs, psmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
  		}	
		return proList;
		
	
	}
	
	
}
