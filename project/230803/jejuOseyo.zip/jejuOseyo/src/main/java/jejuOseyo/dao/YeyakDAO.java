package jejuOseyo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jejuOseyo.vo.YeyakVO;

public class YeyakDAO {
	
	private Connection con;
	private String query;	   // 쿼리문 저장 필드
	private PreparedStatement psmt;
	private ResultSet rs;
	
	public YeyakDAO(Connection con) {
		this.con = con;
	}

	// 예약등록
	public boolean yeInsert(YeyakVO yvo) {
		return false;
	}
	
	// 예약전체목록(페이징)
	public List<YeyakVO> yeSelectAll(double amount,int pageNum) {
		List<YeyakVO> yvoList = new ArrayList<YeyakVO>();
		return yvoList;
	} 
	
	// 예약 확인/취소 상세 조회
	public YeyakVO yeSelect(String yno) {
		YeyakVO yvo = null;
		return yvo;
		
	} 
	
	// 예약 취소 (예약여부, 취소일시가 추가된다. ///////체크아웃지나고 다시 예약 가능한 상태로)
	public boolean yeUpdate(YeyakVO yvo) {
		
		//예약 여부 바꿔주는거랑 취소일시 update됨
		return false;
	} 

}
