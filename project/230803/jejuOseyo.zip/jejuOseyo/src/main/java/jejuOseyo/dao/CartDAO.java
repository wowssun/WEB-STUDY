package jejuOseyo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import jejuOseyo.vo.CartVO;

public class CartDAO {
	
	private Connection con;
	private String query;	   // 쿼리문 저장 필드
	private PreparedStatement psmt;
	private ResultSet rs;
	
	
	public CartDAO(Connection con) {
		this.con = con;
	}

	//장바구니 담기 (등록)
	public boolean cartInsert(CartVO cvo) {
		return false;
	} 
	
	//장바구니 전체 목록(페이징)
	public List<CartVO> cartSelectAll(double amount,int pageNum){
		List<CartVO> cvoList = new ArrayList<CartVO>();
		return cvoList;
	} 
	
	//결제 전 예약 정보조회
	public CartVO cartSelect(int cno){
		CartVO cvo = null;
		return cvo;
		
	} 
	
	//장바구니 삭제
	public boolean cartDelete(int cno){
		return false;
	}
	
	 //장바구니 비우기
	public boolean cartDeleteAll(String 회원아이디){
		return false;
	} 
	

}
